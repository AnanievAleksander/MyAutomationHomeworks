package workspace;

import java.util.Scanner;

public class Exs3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Values");
		System.out.println("Enter value 1 : ");
		int value1 = sc.nextInt();
		System.out.println("Enter value 2 : ");
		int value2 = sc.nextInt();
		
		// Print changed values
		System.out.println("value1 Now is "+ value2);
		System.out.println("value2 Now is "+ value1);
		
		
		
		
	
		}
		
		
		
			
		
	
			


	}

