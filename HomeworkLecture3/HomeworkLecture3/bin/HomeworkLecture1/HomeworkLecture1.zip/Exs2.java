package workspace;

public class Exs2 {

	public static void main(String[] args) {
	
		int value1 = 6;
		int value2 = 30;	
		
		// Add
		int resultSum = (value1 + value2) ;
		System.out.println(resultSum);
		
		// Sub
		int resultSub = (value1 - value2) ;
		System.out.println(resultSub);
		
		//Mult
		int resultMult = (value1 * value2) ;
		System.out.println(resultMult);
		
		//Div
		int resultDiv = (value1 / value2) ;
		System.out.println(resultDiv);
		
		//Fold
		int resultFold = (value1 % value2) ;
		System.out.println(resultFold);
			

	}

}
// OK!!!