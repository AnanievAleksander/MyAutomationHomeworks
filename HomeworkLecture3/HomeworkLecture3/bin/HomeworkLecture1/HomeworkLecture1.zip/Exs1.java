


package workspace;


import java.util.Scanner;

public class Exs1 {

	public static void main(String[] args) {
	
		Scanner scanner = new Scanner (System.in);
		//TypeAndPrint"A"Value
		System.out.println("Enter A:");
		int expectedFromKeyboardA = scanner.nextInt();
		System.out.println("A is:" + expectedFromKeyboardA);
		
		//TypeAndPrint"B"Value
		System.out.println("Enter B:");
		int expectedFromKeyboardB = scanner.nextInt();
		System.out.println("B is:" + expectedFromKeyboardB);
		
		//TypeAndPrint"C"Value
		System.out.println("Enter C:");
		int expectedFromKeyboardC = scanner.nextInt();
		System.out.println("C is:" + expectedFromKeyboardC);
		
		//ComparisonOf"C"Value
		
		
		
		
		
		
	}

}
