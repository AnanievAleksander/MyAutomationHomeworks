package workspace;

import java.util.Scanner;

public class Exs6 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		//a1
		System.out.println("Enter value for a1");
		int a1 = sc.nextInt();
		
		//a2
		System.out.println("Enter value for a2");
		int a2 = sc.nextInt();
		
		//a3
		System.out.println("Enter value for a3");
		int a3 = sc.nextInt();
		
		// Change
		
		System.out.println("a1 = " + a2);
		System.out.println("a2 = " + a3);
		System.out.println("a3 = " + a1);
		
		
		
		
		

		
	}

}
