package Homework3Arrays;

public class Exs1 {
	
	public static void main(String[] args) {
		
		int array[] = new int[5];
			array[0]=10;
			array[1]=66;
			array[2]=12;
			array[3]= -416;
			array[4]= 5;
		int i;
		int temp=0;
		
		
			
			for ( i = 0; i<array.length; ++i ){
				
				if (array[i]%3 ==0){
					
				//System.out.println(array[i]);
				temp = array[i];
			 System.out.println(temp);
				
				
					}
			
					
				}
																				
			}
	}			
			
/// ??????? ////
