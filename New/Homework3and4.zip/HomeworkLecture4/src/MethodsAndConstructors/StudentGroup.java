package MethodsAndConstructors;

public class StudentGroup {

}
