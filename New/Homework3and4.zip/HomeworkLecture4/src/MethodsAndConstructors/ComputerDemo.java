package MethodsAndConstructors;

public class ComputerDemo {

	public static void main(String[] args) {
		
		Computer hp = new Computer();
		Computer acer = new Computer(2000, 100.23, 56, 100);
		Computer asus = new Computer(1999, 2500, true, 2.8, 3.50, "Linux");
		//System.out.println(asus.hardDiskMemory);
		//asus.allParameters();
		//acer.allParameters();
		//hp.allParameters();
		asus.model = "ASUS";
		acer.model = " Acer";
		
		

		System.out.println(asus.price);
		System.out.println(acer.price);
		
		int compare = asus.comparePrice(acer);
		if ( compare == 1){
			System.out.println(asus.model+" is more expencive" );}
			else{
				System.out.println(asus.model + "  is cheaper");
			}
			
		}
			
				
			}
		

		



