package MethodsAndConstructors;


public class Computer {
	
	String operationSystem;
	int year;
	double price;
	boolean isNotebook;
	double hardDiskMemory;
	double freeMemory;
	Computer comp;
	String model;
	
	Computer (){
		isNotebook = false;
		operationSystem = "WinXP";
	}
	
	Computer(int year, double price,double hardDiskMemory,double freeMemory ){
		this();
		this.year =year;
		this.price = price;
		this.hardDiskMemory= hardDiskMemory;
		this.freeMemory = freeMemory;
		
		
			
	}
	
	Computer(int year, double price, boolean isnotebook,double hardDiskMemory,
			double freeMemory,String operationSystem){
		this(year,price,hardDiskMemory,freeMemory);
		this.isNotebook = isnotebook;
		this.operationSystem = operationSystem;
	}
	Computer ( String model){
		this.model = model;
	}
	
		void changeOperationSystem (String newOperationSystem){
			
			operationSystem = newOperationSystem;
			
				}
		
		void useMemory(double memory){
			
			freeMemory = freeMemory - memory;
											
			if(freeMemory < memory  ){
			
				System.out.println( "Not enogh memory");}
		}
			
			void allParameters(){
				String yes = "Yes";
				String no = "No";
															
	System.out.println("Computer Parameters is : " +"Operation System  " +operationSystem + " ," +"Year  "+ year + ","+
				"Price  "+price + ","+"System is Notebook :"+ isNotebook +" ," +"Hard Disk Memory  "+
						hardDiskMemory + ", " +" Free Memory   " + freeMemory  );
				
				 }
			
			int comparePrice(Computer comp){
				
				if ( this.price> comp.price){
					return 1;}
					if ( this.price< comp.price){
						return -1;}
					else;{
							return 0;}
				
						
			}
			
					
					
					
				}
	
									
											
			
				
					
				
			
		
	

