package MethodsAndConstructors;

public class College {

	public static void main(String[] args) {
		
		Student mitko = new Student();
		
		//mitko.upYear();
		//mitko.upYear();
		//mitko.upYear();
		mitko.upYear();
		mitko.upYear();
		System.out.println(mitko.yearInCollege);
		double cash = mitko.recieveScolarship(3.0, 20.0);
		System.out.println(cash);

	}

}
