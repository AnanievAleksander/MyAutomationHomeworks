package MethodsAndConstructors;

public class Student {

		String name;
		String subject;
		double grade;
		int yearInCollege;
		int age;
		boolean isDegree;
		double money;
		
		Student (){
			grade = 4.0;
			yearInCollege = 1;
			isDegree = false;
			money = 0;
		}
		
		Student (String name,String subject,int age ){
			this();
			this.name =name;
			this.subject = subject;
			this.age= age;
		}
		
		void upYear(){
			if (isDegree == false && yearInCollege<= 4){
				yearInCollege = ++yearInCollege;
				}else 
				{isDegree = true;}
				if ( isDegree = true && yearInCollege>4){
					System.out.println(" Student is Degree");}
				}
				
		double recieveScolarship(double min,double amount){		
			if (this.grade>=min && age<30){
				double sum = money + amount;
				return sum;}
				else {
					return money;
				}
			
				
		}
		{
					
					
				}
			
		}

